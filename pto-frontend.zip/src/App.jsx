export default function App() {
  return (
    <div className="p-4 text-center text-xl text-blue-600">
      PTO Central is running!
    </div>
  )
}